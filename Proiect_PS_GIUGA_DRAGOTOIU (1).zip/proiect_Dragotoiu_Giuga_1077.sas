/* crearea unui set de date SAS din fișiere externe */

libname cyber '/home/u64492358/PROIECT';
data cyber.cyber_data;
    infile '/home/u64492358/PROIECT/date_proiect_ps.csv' dsd firstobs=2 ;
    input tara $
          frauda_card
          furt_identitate
          phishing
          pharming
          abuz_date_personale
          cont_spart
          pierdere_date_virus
          pierdere_financiara
          incident_total
          competente_scazute
          competente_de_baza
          competente_avansate
          fara_competente
          utilizare_email
          utilizare_info_produse
          utilizare_retele_soc
          utilizare_banking;
        if missing (tara) then delete;
run;

title 'Structura setului de date';
proc contents data=cyber.cyber_data;
run;

title 'Setul complet de date ';
proc print data=cyber.cyber_data;
run;


/* crearea și folosirea de formate definite de utilizator */

proc format library=cyber;
    value risc_phishing_fmt
        low  -< 15  = 'Risc Scazut'
        15   -< 25  = 'Risc Mediu'
        25   - high = 'Risc Ridicat';
run;

options fmtsearch=(cyber);

data cyber.cyber_formatat;
    set cyber.cyber_data;
    label phishing = 'Nivel phishing (%)';
run;

title 'Distributia tarilor dupa nivelul de phishing';
proc freq data=cyber.cyber_formatat;
    tables phishing / nocum;
    format phishing risc_phishing_fmt.;
run;

/* 3 + 4 */

data cyber.cyber_decalaj;
    set cyber.cyber_data;

    if tara = 'European Union - 28 countries (2013-2020)' then delete;

    /* indicele de decalaj digital */
    indice_decalaj = competente_avansate - fara_competente;

    /* clasificarea tarilor dupa nivelul de maturitate digitala */
    length maturitate_digitala $25;

    if indice_decalaj > 35 then
        maturitate_digitala = 'Decalaj Pozitiv Mare';
    else if indice_decalaj >= 0 then
        maturitate_digitala = 'Decalaj Pozitiv Mic';
    else
        maturitate_digitala = 'Decalaj Negativ';

    label indice_decalaj      = 'Indice decalaj digital'
          maturitate_digitala  = 'Maturitate digitala'
          competente_avansate  = 'Competente avansate (%)'
          fara_competente      = 'Fara competente (%)';
run;

title 'Clasificarea pietelor dupa maturitatea digitala';
proc print data=cyber.cyber_decalaj noobs label;
    var tara competente_avansate fara_competente
        indice_decalaj maturitate_digitala;
run;

title 'Distributia pietelor pe categorii de maturitate digitala';
proc freq data=cyber.cyber_decalaj;
    tables maturitate_digitala / nocum;
run;

data cyber.piete_mature;
    set cyber.cyber_decalaj;
    where maturitate_digitala = 'Decalaj Pozitiv Mare';
run;

title 'Piete cu Decalaj Pozitiv Mare';
proc print data=cyber.piete_mature noobs label;
    var tara competente_avansate fara_competente indice_decalaj;
run;

/* 5 */

data cyber.cyber_functii;
    set cyber.cyber_data;

    media_frauda = round(mean(frauda_card, furt_identitate, pharming), 0.01);

    suma_incidente = sum(frauda_card, furt_identitate, phishing, pharming,
                        abuz_date_personale, cont_spart,
                        pierdere_date_virus, pierdere_financiara);

    max_indicator = max(frauda_card, furt_identitate, phishing, pharming,
                       abuz_date_personale, cont_spart,
                       pierdere_date_virus, pierdere_financiara);

    min_indicator = min(frauda_card, furt_identitate, phishing, pharming,
                       abuz_date_personale, cont_spart,
                       pierdere_date_virus, pierdere_financiara);

    label media_frauda    = 'Media expunerii la frauda'
          suma_incidente  = 'Suma totala incidente'
          max_indicator   = 'Indicator maxim de risc'
          min_indicator   = 'Indicator minim de risc';
run;

title 'Indicatori sintetici de risc per tara';
proc print data=cyber.cyber_functii noobs label;
    var tara media_frauda suma_incidente max_indicator min_indicator;
run;

title 'Statistici agregate ale indicatorilor calculati';
proc means data=cyber.cyber_functii mean min max;
    var media_frauda suma_incidente max_indicator min_indicator;
run;

/* 6 */

data cyber.cyber_fraude;
    set cyber.cyber_data;
    where tara ne 'European Union - 28 countries (2013-2020)';
    keep tara frauda_card furt_identitate phishing pharming
         abuz_date_personale cont_spart pierdere_date_virus
         pierdere_financiara;
run;

data cyber.cyber_competente;
    set cyber.cyber_data;
    where tara ne 'European Union - 28 countries (2013-2020)';
    keep tara competente_scazute competente_de_baza
         competente_avansate fara_competente;
run;

/* sortarea ambelor seturi dupa tara pentru MERGE */
proc sort data=cyber.cyber_fraude;
    by tara;
run;

proc sort data=cyber.cyber_competente;
    by tara;
run;

/* combinarea prin MERGE SAS */
data cyber.cyber_merge;
    merge cyber.cyber_fraude
          cyber.cyber_competente;
    by tara;
run;

title 'Combinare prin MERGE SAS';
proc print data=cyber.cyber_merge noobs;
    var tara frauda_card phishing competente_avansate fara_competente;
run;

/* combinarea prin INNER JOIN SQL */
proc sql;
    create table cyber.cyber_sql as
    select f.tara,
           f.frauda_card,
           f.phishing,
           f.pharming,
           c.competente_avansate,
           c.fara_competente
    from cyber.cyber_fraude as f
    inner join cyber.cyber_competente as c
    on f.tara = c.tara;
quit;

title 'Combinare prin INNER JOIN SQL';
proc print data=cyber.cyber_sql noobs;
run;

/* 7 */

data cyber.cyber_masive;
    set cyber.cyber_data;
    where tara ne 'European Union - 28 countries (2013-2020)';

    /* Masivul indicatorilor de utilizare internet */
    array utilizare{4} utilizare_email utilizare_info_produse
                       utilizare_retele_soc utilizare_banking;

    /* Masivul mediilor europene de referinta */
    array medii{4} _temporary_ (75 70 60 50);

    /* indicatorii sub medie */
    nr_sub_medie = 0;
    do i = 1 to 4;
        if utilizare{i} < medii{i} then nr_sub_medie + 1;
    end;
    drop i;

    /* Recomandare training pe baza numarului de indicatori sub medie */
    length recomandare_training $30;
    if nr_sub_medie = 4 then
        recomandare_training = 'Training Complet';
    else if nr_sub_medie = 3 then
        recomandare_training = 'Training Avansat';
    else if nr_sub_medie = 2 then
        recomandare_training = 'Training Mediu';
    else if nr_sub_medie = 1 then
        recomandare_training = 'Training Basic';
    else
        recomandare_training = 'Training Nerecesat';

    label nr_sub_medie        = 'Nr. indicatori sub medie'
          recomandare_training = 'Recomandare training';
run;

title 'Analiza utilizarii internetului cu masive';
proc print data=cyber.cyber_masive noobs label;
    var tara utilizare_email utilizare_info_produse
        utilizare_retele_soc utilizare_banking
        nr_sub_medie recomandare_training;
run;

title 'Distributia pietelor dupa recomandarea de training';
proc freq data=cyber.cyber_masive;
    tables recomandare_training / nocum;
run;


/* 8 + 9 */


/* Raport descriptiv general */
title 'Statistici descriptive ale indicatorilor de securitate';
proc means data=cyber.cyber_data mean min max std;
    where tara ne 'European Union - 28 countries (2013-2020)';
    var phishing pharming frauda_card pierdere_financiara utilizare_banking;
    label phishing           = 'Phishing (%)'
          pharming            = 'Pharming (%)'
          frauda_card         = 'Frauda card (%)'
          pierdere_financiara = 'Pierdere financiara (%)'
          utilizare_banking   = 'Banking online (%)';
run;

/* Raport detaliat sortat dupa phishing */
proc sort data=cyber.cyber_data out=cyber.cyber_sortat;
    where tara ne 'European Union - 28 countries (2013-2020)';
    by descending phishing;
run;

title 'Raport detaliat sortat dupa nivelul de phishing';
proc print data=cyber.cyber_sortat noobs label;
    var tara phishing pharming frauda_card pierdere_financiara;
    label phishing           = 'Phishing (%)'
          pharming            = 'Pharming (%)'
          frauda_card         = 'Frauda card (%)'
          pierdere_financiara = 'Pierdere financiara (%)';
    sum phishing pharming frauda_card pierdere_financiara;
run;

/* Distributia pietelor dupa recomandarea de training */
title 'Distributia pietelor dupa recomandarea de training';
proc freq data=cyber.cyber_masive;
    tables recomandare_training / nocum;
run;


/* 9  */

title 'Corelatia dintre phishing si pierderea financiara';
proc corr data=cyber.cyber_data;
    where tara ne 'European Union - 28 countries (2013-2020)';
    var phishing;
    with pierdere_financiara;
run;

/* analiza de regresie */
title ' Regresia pierderii financiare in functie de phishing';
proc reg data=cyber.cyber_data;
    where tara ne 'European Union - 28 countries (2013-2020)';
    model pierdere_financiara = phishing;
    plot pierdere_financiara * phishing;
run;
quit;

/* 10 */

/*  distributia tarilor pe recomandari de training */
title 'Distributia pietelor pe recomandari de training';
proc gchart data=cyber.cyber_masive;
    vbar recomandare_training /
        frame
        cframe=white
        coutline=black;
run;
quit;

/* scatter plot phishing vs pierdere financiara */
symbol value=dot i=sm;
title 'Relatia dintre phishing si pierderea financiara';
proc gplot data=cyber.cyber_data;
    where tara ne 'European Union - 28 countries (2013-2020)';
    plot pierdere_financiara * phishing;
run;
quit;